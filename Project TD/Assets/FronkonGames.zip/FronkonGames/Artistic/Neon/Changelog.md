## [1.0.1] - 10-02-2024

# Fix
- 'Remap' function renamed to avoid collisions.

## [1.0.0] - 16-11-2023

- Initial release.